import React from 'react';

export function Home() {
  return (
    <div className="space-y-8">
      <div className="relative h-[60vh]">
        <img
          src="https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=1920"
          alt="Tecidos coloridos"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-6xl font-serif mb-4">Tecidos Exclusivos</h1>
            <p className="text-xl md:text-2xl">Qualidade e elegância para suas criações</p>
          </div>
        </div>
      </div>
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h2 className="text-3xl font-serif text-gray-800 mb-6">Bem-vindo à nossa loja</h2>
        <p className="text-gray-600 leading-relaxed">
          Descubra nossa seleção exclusiva de tecidos finos, cuidadosamente selecionados para
          atender aos mais exigentes padrões de qualidade. Oferecemos uma ampla variedade de
          texturas, cores e padrões para transformar suas ideias em realidade.
        </p>
      </div>
    </div>
  );
}