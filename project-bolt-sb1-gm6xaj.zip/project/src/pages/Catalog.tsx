import React from 'react';
import { FabricCard } from '../components/FabricCard';

const fabrics = [
  {
    name: 'Seda Natural',
    type: 'Tecido Natural',
    description: 'Seda pura com acabamento acetinado, perfeita para peças elegantes.',
    imageUrl: 'https://images.unsplash.com/photo-1576678927484-cc907957088c?auto=format&fit=crop&w=800'
  },
  {
    name: 'Linho Premium',
    type: 'Tecido Natural',
    description: 'Linho de alta qualidade, ideal para roupas de verão.',
    imageUrl: 'https://images.unsplash.com/photo-1620799140188-3b2a02fd9a77?auto=format&fit=crop&w=800'
  },
  {
    name: 'Algodão Egípcio',
    type: 'Tecido Natural',
    description: 'Algodão de fibra longa, macio e durável.',
    imageUrl: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=800'
  },
  {
    name: 'Veludo Italiano',
    type: 'Tecido Sintético',
    description: 'Veludo premium com toque macio e brilho sofisticado.',
    imageUrl: 'https://images.unsplash.com/photo-1620799139507-2a76f79a2f4d?auto=format&fit=crop&w=800'
  }
];

export function Catalog() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-serif text-gray-800 mb-8">Nosso Catálogo</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {fabrics.map((fabric) => (
          <FabricCard key={fabric.name} {...fabric} />
        ))}
      </div>
    </div>
  );
}