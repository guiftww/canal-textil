import React from 'react';
import { Phone, Mail, MessageCircle } from 'lucide-react';
import { ContactForm } from '../components/ContactForm';

export function Contact() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="grid md:grid-cols-2 gap-12">
        <div>
          <h2 className="text-3xl font-serif text-gray-800 mb-6">Entre em Contato</h2>
          <div className="space-y-4 mb-8">
            <div className="flex items-center">
              <Mail className="h-5 w-5 text-rose-600 mr-3" />
              <a href="mailto:contato@lojadetecidos.com" className="text-gray-600 hover:text-rose-600">
                contato@lojadetecidos.com
              </a>
            </div>
            <div className="flex items-center">
              <Phone className="h-5 w-5 text-rose-600 mr-3" />
              <a href="tel:+551199999999" className="text-gray-600 hover:text-rose-600">
                (11) 9999-9999
              </a>
            </div>
            <div className="flex items-center">
              <MessageCircle className="h-5 w-5 text-rose-600 mr-3" />
              <a
                href="https://wa.me/551199999999"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-600 hover:text-rose-600"
              >
                WhatsApp
              </a>
            </div>
          </div>
          <ContactForm />
        </div>
        <div className="hidden md:block">
          <img
            src="https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800"
            alt="Tecidos"
            className="w-full h-full object-cover rounded-lg shadow-lg"
          />
        </div>
      </div>
    </div>
  );
}