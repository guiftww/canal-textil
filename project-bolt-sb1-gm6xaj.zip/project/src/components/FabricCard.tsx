import React from 'react';

interface FabricCardProps {
  name: string;
  type: string;
  description: string;
  imageUrl: string;
}

export function FabricCard({ name, type, description, imageUrl }: FabricCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
      <img
        src={imageUrl}
        alt={name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800">{name}</h3>
        <p className="text-sm text-rose-600 mb-2">{type}</p>
        <p className="text-gray-600 text-sm">{description}</p>
      </div>
    </div>
  );
}